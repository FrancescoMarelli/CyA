#include "Set.h"

Set::Set() {
  sz_ = 64;
}

Set::Set(unsigned& size) {
    sz_= size;
}

Set::~Set(){}




